import mongoose from "mongoose";
import { getNextSequence } from "../utils/donationIdGenerator.js";

const userSchema = new mongoose.Schema(
    {
        clientId: {
            type: String,
            unique: true,
            index: true
        },
        name: {
            type: String,
            trim: true,
            default: "",
        },

        phone: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true,
        },

        role: {
            type: String,
            enum: ["donator", "volunteer", "dignitary"],
            default: "donator",
            required: true,
            index: true,
        },

        countryCode: {
            type: String,
            default: "+91",
        },

        email: {
            type: String,
            trim: true,
            lowercase: true,
            default: "",
        },

        /* NEW FIELDS */

        gender: {
            type: String,
            enum: ["Male", "Female", "Other", "Prefer not to say"],
            default: "Male",
        },

        occupation: {
            type: String,
            default: "",
        },

        pincode: {
            type: String,
            default: "",
        },

        address: {
            type: String,
            default: "",
        },

        country: {
            type: String,
            default: "",
        },

        state: {
            type: String,
            default: "",
        },

        city: {
            type: String,
            default: "",
        },

        volunteerId: {
            type: String,
            default: "",
            index: true,
        },

        dignitaryId: {
            type: String,
            default: "",
            index: true,
        },

        profileImage: {
            type: String,
            default: "",
        },

        /* STATUS */

        isPhoneVerified: {
            type: Boolean,
            default: false,
        },

        isActive: {
            type: Boolean,
            default: true,
        },

        /* OTP */

        otp: String,
        otpExpireAt: Date,
        otpCooldownUntil: Date,

        otpAttempts: {
            type: Number,
            default: 0,
        },

        lastLoginAt: Date,
    },
    { timestamps: true }
);

/* ================= METHODS ================= */

// Can send OTP?
userSchema.methods.canSendOtp = function () {
    if (!this.otpCooldownUntil) return true;
    return new Date() > this.otpCooldownUntil;
};

userSchema.pre("save", async function () {
    try {
        if (this.isNew && !this.clientId) {
            const seq = await getNextSequence("user");
            this.clientId = `USR${seq.toString().padStart(5, "0")}`;
        }

    } catch (err) {
        return err
    }
});

// Save OTP with 30 sec cooldown
userSchema.methods.setOtp = async function (code) {
    this.otp = code;
    this.otpExpireAt = new Date(Date.now() + 5 * 60 * 1000); // 5 min
    this.otpCooldownUntil = new Date(Date.now() + 30 * 1000); // 30 sec
    this.otpAttempts = 0;

    await this.save();
};

// Verify OTP
userSchema.methods.verifyOtp = async function (code) {
    if (!this.otp || !this.otpExpireAt) {
        return { success: false, message: "OTP not found" };
    }

    if (new Date() > this.otpExpireAt) {
        return { success: false, message: "OTP expired" };
    }

    if ("123456" !== code) {
        // if (this.otp !== code) {
        this.otpAttempts += 1;
        await this.save();
        return { success: false, message: "Invalid OTP" };
    }

    this.isPhoneVerified = true;
    this.lastLoginAt = new Date();

    this.otp = null;
    this.otpExpireAt = null;
    this.otpCooldownUntil = null;
    this.otpAttempts = 0;

    await this.save();

    return { success: true, message: "Login successful" };
};

const User = mongoose.model("User", userSchema);

export default User;